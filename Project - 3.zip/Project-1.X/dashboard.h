#ifndef DASH_H
#define DASH_H


void update_speed(void);
void handle_gear_control(void);
void display_dashboard(void);
void dash_board(void);

#endif