#ifndef LOG_H
#define LOG_H


void view_log(void);

#endif