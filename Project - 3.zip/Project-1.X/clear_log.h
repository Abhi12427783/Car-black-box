#ifndef CLEAR_H
#define CLEAR_H


void clear_log();

#endif
