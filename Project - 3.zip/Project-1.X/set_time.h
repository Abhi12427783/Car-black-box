#ifndef SET_H
#define SET_H


void set_time(void);

#endif