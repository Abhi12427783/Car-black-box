#ifndef DOWN_H
#define DOWN_H

void download_log(void);

#endif