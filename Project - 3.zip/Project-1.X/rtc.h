#ifndef RTC_H
#define RTC_H

void display_time(void);
void get_time(void);
void init_rtc(void);

#endif 